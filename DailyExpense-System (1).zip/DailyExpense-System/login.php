<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Login</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <style>
        .login-form {
            width: 340px;
            margin: 50px auto;
            font-size: 15px;
        }

        .login-form form {
            margin-bottom: 15px;
            background: #fff;
            box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
            padding: 30px;
            border: 1px solid #ddd;
        }

        .login-form h2 {
            color: #636363;
            margin: 0 0 15px;
            position: relative;
            text-align: center;
        }

        .login-form h2:before {
            left: 0;
        }

        .login-form h2:after {
            right: 0;
        }

        .login-form .hint-text {
            color: #999;
            margin-bottom: 30px;
            text-align: center;
        }

        .login-form a:hover {
            text-decoration: none;
        }

        .form-control,
        .btn {
            min-height: 38px;
            border-radius: 2px;
        }

        .btn {
            font-size: 15px;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="login-form">
        <form action="" method="POST" autocomplete="off">
            <h2 class="text-center">Personal Expense Tracker</h2>
            <p class="hint-text">Login Panel</p>
            <div class="form-group">
                <input type="text" name="email" class="form-control" placeholder="Email" required="required">
            </div>
            <div class="form-group">
            <input type="password" id="password" name="password" class="form-control" placeholder="Password" onkeyup="maskPassword()" required="required">

            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-success btn-block" style="border-radius:0%;">Login</button>
            </div>
        </form>
        <p class="text-center">Don't have an account?<a href="register.php" class="text-danger"> Register Here</a></p>
    </div>

    <!-- Bootstrap core JavaScript -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/feather.min.js"></script>
    <script>
    function maskPassword() {
        var passwordInput = document.getElementById("password");
        var maskedPassword = "";

        for (var i = 0; i < passwordInput.value.length; i++) {
            maskedPassword += "*"; // Append '*' for each character
        }

        passwordInput.value = maskedPassword; // Set the value of input to masked password
        passwordInput.type = "password"; // Set input type to password
    }
</script>


</body>

</html>
